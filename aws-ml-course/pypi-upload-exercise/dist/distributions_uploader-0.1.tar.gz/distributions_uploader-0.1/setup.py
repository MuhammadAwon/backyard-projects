from setuptools import setup

setup(name='distributions_uploader',
      version='0.1',
      description='Gaussian & Binomialdistribution distributions',
      packages=['distributions_uploader'],
      zip_safe=False)
